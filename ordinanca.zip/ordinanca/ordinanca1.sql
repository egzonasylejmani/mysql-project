CREATE DATABASE IF NOT EXISTS Ordinanca_Egzona;


USE Ordinanca_Egzona;


CREATE TABLE Roles (
    Role_ID INT PRIMARY KEY AUTO_INCREMENT,
    Role_Name VARCHAR(50) UNIQUE
);

CREATE TABLE Speciality (
    Speciality_ID INT PRIMARY KEY AUTO_INCREMENT,
    Speciality_Name VARCHAR(255) UNIQUE
);


INSERT INTO Speciality (Speciality_Name) VALUES
('Dentist'),
('Orthodontist'),
('Oral Surgeon'),
('Periodontist'),
('Endodontist'),
('Prosthodontist');

select * from Speciality where Speciality_name like '%dontist';

INSERT INTO Roles (Role_Name) VALUES ( 'Admin');
INSERT INTO Roles (Role_Name) VALUES ( 'Superadmin');

CREATE TABLE Users (
    User_ID INT PRIMARY KEY AUTO_INCREMENT,
    Emri VARCHAR(255),
    Mbiemri VARCHAR(255),
    Adresa VARCHAR(255),
    Numer_kontakti VARCHAR(20),
    Speciality_ID int, -- Assuming Speciality is relevant for users
    Role_ID INT,
    FOREIGN KEY (Speciality_ID) REFERENCES Speciality(Speciality_ID),
    FOREIGN KEY (Role_ID) REFERENCES Roles(Role_ID)
    
);

CREATE TABLE User_Specialities (
    User_ID INT,
    Speciality_ID INT,
    PRIMARY KEY (User_ID, Speciality_ID),
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID),
    FOREIGN KEY (Speciality_ID) REFERENCES Speciality(Speciality_ID)
);

INSERT INTO User_Specialities (User_ID, Speciality_ID) VALUES (1, 2);
INSERT INTO User_Specialities (User_ID, Speciality_ID) VALUES (2, 1);
INSERT INTO User_Specialities (User_ID, Speciality_ID) VALUES (2, 2);
INSERT INTO User_Specialities (User_ID, Speciality_ID) VALUES (4, 1);
INSERT INTO User_Specialities (User_ID, Speciality_ID) VALUES (4, 4);

select * from User_Specialities;
SELECT
    U.Emri AS User_Name,
    S.Speciality_Name
FROM
    Users U
JOIN
    User_Specialities US ON U.User_ID = US.User_ID
JOIN
    Speciality S ON US.Speciality_ID = S.Speciality_ID
WHERE
    U.Emri = 'Fatjona';
    
 insert into Users (Emri, Mbiemri, Adresa, Numer_kontakti, Speciality_ID, Role_ID) values ('Egzona', 'Sylejmani', 'Stanoc i Ulet', '045123123', 1, 1);
 insert into Users (Emri, Mbiemri, Adresa, Numer_kontakti, Speciality_ID, Role_ID) values ('Fatjona', 'Kajtazi', 'Vushtrri', '045123123', 2, 2);
 insert into Users (Emri, Mbiemri, Adresa, Numer_kontakti, Speciality_ID, Role_ID) values ('Adelina', 'Sylejmani', 'Mitrovice', '045123153', 3, 2);
 insert into Users (Emri, Mbiemri, Adresa, Numer_kontakti, Speciality_ID, Role_ID) values ('Zanfina', 'Dobratiqi', 'Prishtine', '045123423', 4, 1);
  


CREATE TABLE Pacientet (
    Pacient_ID INT PRIMARY KEY AUTO_INCREMENT,
    Emri VARCHAR(255),
    Mbiemri VARCHAR(255),
    Adresa VARCHAR(255),
    Numer_kontakti VARCHAR(20)
);

insert into Pacientet(Emri, Mbiemri, Adresa, Numer_kontakti) values ('Albulena', 'Sadiku', 'Gjilan', '04123123');
insert into Pacientet(Emri, Mbiemri, Adresa, Numer_kontakti) values ('Shqipe', 'Shahu', 'Prizren', '04123173');
insert into Pacientet(Emri, Mbiemri, Adresa, Numer_kontakti) values ('Azra', 'Sadiku', 'Mitrovice', '04123123');
insert into Pacientet(Emri, Mbiemri, Adresa, Numer_kontakti) values ('Lena', 'Latifi', 'Gjakove', '04123223');
insert into Pacientet(Emri, Mbiemri, Adresa, Numer_kontakti) values ('Elena', 'GJikolli', 'Suhareke', '04123128');


CREATE TABLE Termini (
    Termini_ID INT PRIMARY KEY AUTO_INCREMENT,
    Data DATE,
    Ora TIME,
    Pacient_ID INT,
    User_ID INT, -- Modified from Mjek_ID to User_ID
    FOREIGN KEY (Pacient_ID) REFERENCES Pacientet(Pacient_ID),
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID)
);

insert into Termini (Data, Ora , Pacient_ID, User_ID) values ('2022-02-22', '12:00:00', 1, 1);
insert into Termini (Data, Ora , Pacient_ID, User_ID) values ('2022-02-23', '15:00:00', 2, 2);
insert into Termini (Data, Ora , Pacient_ID, User_ID) values ('2022-02-24', '16:00:00', 3, 2);
insert into Termini (Data, Ora , Pacient_ID, User_ID) values ('2022-02-25', '17:00:00', 4, 2);
insert into Termini (Data, Ora , Pacient_ID, User_ID) values ('2022-02-26', '18:00:00', 5, 2);




 CREATE TABLE Trajtimet_Dentare (
    Trajtim_ID INT PRIMARY KEY AUTO_INCREMENT,
    Emri_i_trajtimit VARCHAR(255),
    Kosto DECIMAL(10, 2)
);

insert into Trajtimet_Dentare (Emri_i_trajtimit, Kosto) values ('Ndreqje e dhamit te fundit numri 32', '400');
insert into Trajtimet_Dentare(Emri_i_trajtimit, Kosto) values ('Pastrim i dhembeve','200');
insert into Trajtimet_Dentare(Emri_i_trajtimit, Kosto) values('Vendosje bllombes','150');
insert into Trajtimet_Dentare(Emri_i_trajtimit, Kosto) values('Heqje dhembi' , '40');
insert into Trajtimet_Dentare(Emri_i_trajtimit, Kosto) values('Rregullim dhembi','250');


CREATE TABLE Pagesat (
    Pagesa_ID INT PRIMARY KEY AUTO_INCREMENT,
    Termini_ID INT,
    Trajtim_ID int,
    Metoda_e_pageses VARCHAR(50),
    FOREIGN KEY (Termini_ID) REFERENCES Termini(Termini_ID),
    FOREIGN KEY (Trajtim_ID) REFERENCES Trajtimet_Dentare(Trajtim_ID)
);


insert into Pagesat(Termini_ID, Trajtim_ID, Metoda_e_pageses) values ( 1, 1, 'cash');
insert into Pagesat(Termini_ID, Trajtim_ID, Metoda_e_pageses) values ( 1, 2, 'creditcard');
insert into Pagesat(Termini_ID, Trajtim_ID, Metoda_e_pageses) values ( 1, 3, 'cash');
insert into Pagesat(Termini_ID, Trajtim_ID, Metoda_e_pageses) values ( 1, 4, 'creditcard');
insert into Pagesat(Termini_ID, Trajtim_ID, Metoda_e_pageses) values ( 1, 5, 'cash');


 CREATE TABLE Historia_e_Pacienteve (
    Historia_ID INT PRIMARY KEY AUTO_INCREMENT,
    Pacient_ID INT,
    Diagnoza VARCHAR(255),
    FOREIGN KEY (Pacient_ID) REFERENCES Pacientet(Pacient_ID)
);


insert into Historia_e_Pacienteve (Pacient_ID, Diagnoza) values (1, 'Caviteti dental');
insert into Historia_E_Pacienteve(Pacient_ID,Diagnoza) values (2,'Parodontiti');
insert into Historia_E_Pacienteve(Pacient_ID,Diagnoza) values (3,'Plakja dentare');
insert into Historia_E_Pacienteve(Pacient_ID,Diagnoza) values (4,'Mjekimi i dhembeve të thyer');
insert into Historia_E_Pacienteve(Pacient_ID,Diagnoza) values (5,'Implantet dentare');
 
 -- QUERY
 -- mesatarja e kostos se termineve
SELECT AVG(Kosto) AS Mesatarja_e_Kostos
FROM Trajtimet_Dentare;

-- me kosto maksimale
SELECT MAX(Kosto) AS Kostoja_Maksimale
FROM Trajtimet_Dentare;

-- ketu i kemi selektu pacientat me diagnozat e tyre //
SELECT 
    P.Emri AS Emri_Pacientit,
    P.Mbiemri AS Mbiemri_Pacientit,
    H.Diagnoza
FROM Pacientet P
LEFT JOIN Historia_e_Pacienteve H ON P.Pacient_ID = H.Pacient_ID;
    
    -- lista e pacienteve dhe data e fundit e trajtimit te tyre
    SELECT 
    P.Emri AS Emri_Pacientit,
    MAX(T.Data) AS Data_e_Trajtimit
    FROM Pacientet P
	JOIN Termini T ON P.Pacient_ID = T.Pacient_ID
	GROUP BY P.Pacient_ID;

-- menyra e pageses 
SELECT 
    Termini.Termini_ID,
    Pagesat.Metoda_e_pageses
FROM Termini
JOIN Pagesat ON Termini.Termini_ID = Pagesat.Termini_ID;
    
    -- cili pacient ka pas ma shum termine
SELECT 
    P.Emri AS Emri_Pacientit,
    P.Mbiemri AS Mbiemri_Pacientit,
    COUNT(T.Termini_ID) AS Numri_Total_i_Terminave
FROM Pacientet P
JOIN Termini T ON P.Pacient_ID = T.Pacient_ID
GROUP BY P.Pacient_ID
ORDER BY Numri_Total_i_Terminave DESC LIMIT 1;

-- te dhenat e pacientit dhe diagnoza e tyre 
SELECT 
    P.Emri AS Emri_Pacientit,
    P.Mbiemri AS Mbiemri_Pacientit,
    H.Diagnoza
FROM Pacientet P
JOIN Termini T ON P.Pacient_ID = T.Pacient_ID
LEFT JOIN Historia_e_Pacienteve H ON P.Pacient_ID = H.Pacient_ID;
    
    -- sa termina jane ne ate dite dhe kush i ka ato termina
    SELECT 
    T.Data,
    COUNT(T.Termini_ID) AS Numri_Terminave,
    U.Emri AS Emri_Perdoruesit,
    U.Mbiemri AS Mbiemri_Perdoruesit
FROM Termini T
JOIN Users U ON T.User_ID = U.User_ID
WHERE T.Data = '2022-02-23' 
GROUP BY T.Data, U.User_ID;

-- specialitetet dmth numri sa e kane ate drejtim dhe kush e ka
SELECT 
    S.Speciality_Name,
    COUNT(U.User_ID) AS Numri_Perdoruesve,
    GROUP_CONCAT(U.Emri, ' ', U.Mbiemri) AS Emrat_Perdoruesve
FROM Speciality S
LEFT JOIN User_Specialities US ON S.Speciality_ID = US.Speciality_ID
LEFT JOIN Users U ON US.User_ID = U.User_ID
GROUP BY 
    S.Speciality_ID;


 -- emri mbiemri i atyre qe e kane rolin e adminit
SELECT 
    U.Emri AS Emri_Perdoruesit,
    U.Mbiemri AS Mbiemri_Perdoruesit
FROM Users U
JOIN Roles R ON U.Role_ID = R.Role_ID
WHERE R.Role_Name = 'Admin';

-- terminet qe jane kry , cilen date , edhhe emri trajtimit
SELECT 
    T.Termini_ID,
    T.Data,
    U.Emri AS Emri_Perdoruesit,
    U.Mbiemri AS Mbiemri_Perdoruesit,
    TD.Emri_i_trajtimit
FROM Termini T
JOIN Users U ON T.User_ID = U.User_ID
JOIN Pagesat P ON T.Termini_ID = P.Termini_ID
JOIN Trajtimet_Dentare TD ON P.Trajtim_ID = TD.Trajtim_ID;
